<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018-03-11
 * Time: 16:49
 * 用户的入口文件
 */
include('Core/Application.class.php');
Application::run();