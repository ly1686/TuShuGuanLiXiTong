<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018-03-11
 * Time: 21:36
 *
 */
class ManagerControl{
    //负责登录的逻辑验证
    public function checkLogin(){
            if (isset($_POST['submit'])){
                //对提交的表单数据取值
                $username = $_POST['username'];
                $password = md5($_POST['password']);
                //创建模型对象
                $Manager = new ManagerModel();
                //为模型对象Manager属性赋值
                $Manager->username = $username;
                $Manager->password = $password;
                //调用检查用户和密码方法
                $count = $Manager->checkLogin();
                //判断返回行数
                if ($count>0){
                    //登录成功
                    $_SESSION['count'] = $count;
                    $Manager->updateLoginInfo($count['id']);
                    $this->jump('index.php?Admin/Manager/index');
                }else{
                    //登录失败
                    $this->error('index.php?Admin/Manager/login');
                }
            }
    }
}