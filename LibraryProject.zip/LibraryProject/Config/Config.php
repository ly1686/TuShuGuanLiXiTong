<?php
/**
 * 设置系统全局默认配置内容
 **/
$config = array(
    'URL_MODEL' => 2,
    'db_host'   => 'localhost',
    'db_port'   => 3306,
    'db_user'   => 'root',
    'db_pwd'    => '',
    'db_dbname' => 'library',   // 数据库名称
    'db_charset'    => 'utf-8',
    'db_prefix'     => 'lb_',   // 表前缀
    'default_group'     => 'Home',  // 默认的分组
    'default_module'    => 'Index', // 默认的模块
    'default_action'    => 'index', // 默认的动作
    'image_upload_size' => 100000,  // 图片大小
    'image_mime'    => array(
        'image/png',
        'image/x-png',
        'image/jpeg',
        'image/pjpen',
        'image/gif',
    ),
);
