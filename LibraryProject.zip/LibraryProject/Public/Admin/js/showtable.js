//设置后台首页的表格是否显示的效果
function show(obj) {
    obj.style.background = "#b6c6d7";
    obj.style.textShadow = "0 1px 0 #FFF";
}

function noshow(obj) {
    obj.style.background = "";
}