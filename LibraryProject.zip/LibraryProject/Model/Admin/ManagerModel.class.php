<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018-03-11
 * Time: 21:11
 * 主要实现登录验证的 sql 语句，以及管理员登录信息的更新。
 */
class ManagerModel extends Model{
    protected $tablename = 'manager';


    public function checkLogin(){
        //生成sql语句
        $sql = "select * from {$this->getTableName()} WHERE name='{$this->username}' ";
        $sql .= "and password='{$this->password}'";
        $this->db->query($sql);//执行查询
        $count = $this->db->fetch_assoc();//获取一行记录
        return $count;//将行数返回
    }

    public function checkTypeOne($username){
        $sql = "select * from {$this->getTableName()} WHERE name='{$username}'";
        $this->db->query($sql);
        $row = $this->db->fetch_assoc();
        return $row;
    }

    public function updateLoginInfo($id){
        //生成sql语句
        $time = time();
        $data = array(
            'id'=>$id,
            'logintime'=>$time,
            'loginip'=>$_SERVER["REMOTE_ADDR"]
        );
        $this->update($data);//执行修改
    }

    public function charset(){
        $sql = "show variables like 'character_set_system'";
        $this->db->query($sql);
        $charset = $this->db->fetch_assoc();
        return $charset;
    }

}