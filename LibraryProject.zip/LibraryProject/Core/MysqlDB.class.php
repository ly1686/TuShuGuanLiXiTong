<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018-03-11
 * Time: 15:59
 * 定义工程的数据库访问类
 */
class MysqlDB{
    private $host;          //主机地址
    private $port;          //端口
    private $username;  //用户名
    private $password;  //密码
    private $database;  //数据库
    private $charset;   //编码
    private $prefix;    //表前缀
    private $link;      //链接资源
    private $result;    //结果集资源
    private static $instance;   //当前类的对象

    //创建对象单例模式
    public static function getInstance(){
        if(!(self::$instance instanceof self)){
            self::$instance = new self();
        }
        return self::$instance;
    }

    //防止对象克隆
    private function __clone()
    {
        // TODO: Implement __clone() method.
    }

    //参数param：所有数据库相关信息，默认为空数组
    private function __construct($param = array()){
        //判断是否传递数组元素，如果传递，使用传递的值，否则使用默认值
        $this->host = isset($param['host']) ? $param['host'] : $GLOBALS['config']['db_host'];
        $this->port = isset($param['port']) ? $param['port'] : $GLOBALS['config']['db_port'];
        $this->username = isset($param['username']) ? $param['username'] : $GLOBALS['config']['db_user'];
        $this->password = isset($param['password']) ? $param['password'] : $GLOBALS['config']['db_pwd'];
        $this->database = isset($param['database']) ? $param['database'] : $GLOBALS['config']['db_dbname'];
        $this->charset = isset($param['charset']) ? $param['charset'] : $GLOBALS['config']['db_charset'];
        $this->prefix = isset($param['prefix']) ? $param['prefix'] : $GLOBALS['config']['db_prefix'];
        $this->connect();
        $this->select_db();
        $this->setcharset();
    }

    //连接服务器，将链接资源保存到当前对象的 link 属性中
    private function connect(){
        $this->link = mysqli_connect($this->host, $this->username, $this->password);
    }

    //选择数据库
    private function select_db(){
        mysqli_select_db($this->link, $this->database);
    }

    //设置编码
    private function setcharset(){
        mysqli_query('set names ' . $this->charset, $this->link);
    }

    //返回表前缀
    public function prefix(){
        return $this->prefix;
    }

    //发送 sql 语句
    public function query($query){
        $this->result = mysqli_query($this->link, $this->link);
    }

    //获取结果集中一行数据
    public function fetch_assoc(){
        return mysqli_fetch_assoc($this->result);
    }

    //获取结果集中总行数
    public function num_rows(){
        return mysqli_num_rows($this->result);
    }

    //获取最后一次插入数据的ID值
    public function insert_id(){
        return mysqli_insert_id($this->link);
    }

    //获取受影响行数
    public function affected_rows(){
        return mysqli_affected_rows($this->link);
    }

    //关闭链接
    public function close(){
        mysqli_close($this->link);
    }

    //析构函数
    public function __destruct(){
        $this->close();
    }
}