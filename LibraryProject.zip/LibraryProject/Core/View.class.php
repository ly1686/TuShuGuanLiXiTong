<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018-03-11
 * Time: 15:55
 * 定义工程文件的父类，内容是继承 Smarty 模板，采用 Smarty 模板分离前台后台。
 */
class View extends Smarty{

}