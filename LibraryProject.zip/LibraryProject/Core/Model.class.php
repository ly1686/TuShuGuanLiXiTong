<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018-03-11
 * Time: 2:14
 * 定义工程模型文件的父类，它主要完成解析表结构、插入数据、删除数据、更新数据、查询数据的功能。
 */
class Model{
    protected $db;                   // MysqlDB 类对象
    protected $_fields = array();   // 数据表结构
    protected $_pk;                  // 表中的主键

    // 构造函数
    public function __construct()
    {
        $this->db = MysqlDB::getInstance();
        $this->_getFields();
    }

    // 构造表名（前缀+表的真实名字）
    protected function getTableName(){
        return $this->db->prefix() . $this->tablename;
    }

    // 解析表结构
    private function _getFields(){
        $sql = "desc {$this->getTableName()}";
        $this->db->query($sql);
        $fieldCount = $this->db->num_rows();    // 字段总数
        for ($i=0; $i<$fieldCount; $i++){
            $row = $this->db->fetch_assoc();    // 获取一行数据
            // 将字段名放到 fields 属性数据
            $this->_fields [] = $row['Field'];
            if ($row['Key'] == 'PRI')//如果是主键
                $this->_pk = $row['Field'];     // 将主键字段名放在 pk 属性中
        }
    }

    /**
     * 数据过滤功能
     * @param array $data：所有要过滤的数据
     * @return array
     */
    private function _dataFilter($data){
        $keys = array_keys($data);
        $row = array();             // 空数组
        foreach($keys as $value){
            if (in_array($value, $this->_fields)){
                $row[$value] = $data[$value];
            }
        }
        return $row;
    }

    /**
     * 自动数据录入功能
     * @param  array $data:要录入的数据的数组 '字段名'=>值, '字段名'=>值
     * @return mixed
     */
    public function insert($data){
        $data = $this->_dataFilter($data);
        $keys = array_keys($data);
        $values = array_values($data);
        $sql = "insert into {$this->getTableName()} (" . implode(',', $keys) . ")"; //implode();拼接字符串
        $sql .= "values('";
        $sql .= implode("','", $values);
        $sql .= "')";
        $this->db->query($sql);
        return $this->db->insert_id();
    }

    /**
     * 自动数据删除功能
     * @param int $id：要删除的数据ID
     * @return mixed
     */
    public function delete($id){
        $sql = "delete from {$this->getTableName()} WHERE {$this->_pk} = '$id'";
        $this->db->query($sql);
        return $this->db->affected_rows();
    }

    /**
     * 自动数据修改功能
     * @param array $data：要修改的数据的数组 '字段名'=>值, '字段名'=>值
     * @return mixed
     */
    public function update(array $data){
        $data = $this->_dataFilter($data);
        $sql = "update {$this->getTableName()} set ";
        // 循环遍历参数数组
        foreach ($data as $key => $value) {
            // 如果当前元素的名和主键名相同，则不连接字符串
            if ($key == $this->_pk)
                continue;
            $sql = $sql . $key . "='" . $value . "',";
        }
        $sql = rtrim($sql, ',');        // 去掉最后一个逗号
        // 修改连接条件
        $sql .= ' where ' . $this->_pk . "='" . $data[$this->_pk] . "'";
        $this->db->query($sql);
        return $this->db->affected_rows();
    }

    /**
     * 查询所有数据
     * @return array
     */
    public function fetchAll(){
        $sql = "select * from {$this->getTableName()} ORDER BY $this->_pk ASC";
        $data = array();
        $this->db->query($sql);
        $num = $this->db->num_rows();
        for ($i=0; $i<$num; $i++){
            $data [] = $this->db->fetch_assoc();
        }
        return $data;
    }

    /**
     * 查询一条数据
     * @param $id
     * @return mixed
     */
    public function fetchRow($id){
        $sql = "select * from {$this->getTableName()} WHERE {$this->_pk}='$id'";
        $this->db->query($sql);
        $row = $this->db->fetch_assoc();
        return $row;
    }

    /**
     * 批量删除功能
     * @param array $data：要被删除的数据的 id 数组
     * @return mixed
     */
    public function deleteAll($data){
        $where = implode(',', $data);
        $sql = "delete from {$this->getTableName()} WHERE {$this->_pk} IN (" . $where . ")";
        $this->db->query($sql);
        return $this->db->affected_rows();
    }
}
