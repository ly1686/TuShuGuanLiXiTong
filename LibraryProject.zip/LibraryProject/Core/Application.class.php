<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018-03-10
 * Time: 23:30
 * 这是工程的真正入口文件。它主要完成：初始化工程目录、初始化核心文件、初始化访问路径、初始化自动加载，
 * 请求转发页面这些功能。
 */
class Application{
    /**
     * 初始化工程目录常量
     */
    private static function _initDirConst(){
        define('ROOT', str_replace("\\", "/",
            dirname(dirname(__FILE__))));                   // 定义根路径
        define('CONFIG_DIR', ROOT . '/Config');                 // 配置文件路径
        define('CONTROL_DIR', ROOT . '/Control');               // 控制器路径
        define('CORE_DIR', ROOT . '/Core');                     // 核心路径
        define('MODEL_DIR', ROOT . '/Model');                   // 模型路径
        define('PUBLIC_DIR', ROOT . '/Public');                 // 资源路径
        define('UPLOAD_DIR', PUBLIC_DIR . '/Uploads');          // 上传路径
        define('VIEW_DIR', ROOT . '/View');                      // 视图（模板）路径
        define('TOOLS_DIR', CORE_DIR . '/Tools');               // 工具类
    }

    /**
     * 初始化核心文件
     */
    private static function _initInclude(){
        include(CONFIG_DIR . '/Config.php');
        include(CORE_DIR . '/MysqlDB.class.php');
        include(CORE_DIR . '/Model.class.php');
        include(TOOLS_DIR . '/Smarty/Smarty.class.php');
        include(TOOLS_DIR . '/Page.class.php');
        include(TOOLS_DIR . '/ImageFile.class.php');
        include(CORE_DIR . '/View.class.php');
        include(CORE_DIR . '/Control.class.php');
        $GLOBALS['config'] = $config;
    }

    /**
     * 初始化 URL 参数，访问路径
     */
    private static function _initParams(){
        if ($GLOBALS['config']['URL_MODEL'] == 1){
            $group = isset($_GET['group']) ? $_GET['group'] : $GLOBALS['config']['default_group'];
            $module = isset($_GET['module']) ? $_GET['module'] : $GLOBALS['config']['default_module'];
            $action = isset($_GET['action']) ? $_GET['action'] : $GLOBALS['config']['default_action'];
        }else if ($GLOBALS['config']['URL_MODEL'] == 2){
            // http://www.study.com/index.php?分组/模块/动作/id/10/flag/20
            $str = $_SERVER['QUERY_STRING'];
            if (empty($str)){// 分组/模块/动作/参数名1/值1/参数名2/值2
                $str = $GLOBALS['config']['default_group'] . '/' . $GLOBALS['config']['default_module'] . '/' .
                    $GLOBALS['config']['default_action'];
            }
            $url = explode('/', $str);      // 分割字符串
            $count = count($url);
            $group = $url[0];   //分组名
            $module = $url[1];  // 模块名
            $action = $url[2];  // 动作名
            for ($i=3; $i<$count; $i+=2){
                $_GET[$url[$i]] = $url[$i+1];
            }
            // ucfirst 设置第一个字母为大写; strtolower 设置字符串全部小写
            $group = ucfirst(strtolower($group));
            $module = ucfirst(strtolower($module));

            define('GROUP', $group);
            define('MODULE', $module);
            define('ACTION', $action);
        }
    }

    /**
     * 初始化类的自动加载机制
     */
    private static function _initAutoload(){
        spl_autoload_register(array(
            __CLASS__,
            'autoload'
        ));
    }

    private static function autoload($className){
        if (is_file(MODULE_DIR . '/' . "$className.class.php")){
            include(MODEL_DIR . '/' . $className . '.class.php');
        }else{
            Control::error('index.php', '请正常访问', 1);
            exit(0);
        }
    }

    /**
     * 请求转发
     */
    private static function _initDispatch(){
        $control = MODULE . 'Control';
        $action = ACTION;
        if (is_file('Control/' . GROUP . '/' . $control . '.class.php')){
            include ('Control/' . GROUP . '/' . $control . '.class.php');
        }else{
            Control::error('index.php', '请正常访问', 1);
            exit(0);
        }
        $obj = new $control();
        $obj->$action();
    }

    /**
     * 开始运行，文件的入口文件
     */
    public static function run(){
        self::_initDirConst();      // 初始化目录常量
        self::_initInclude();       // 初始化文件包含
        echo CONFIG_DIR; return;
        self::_initParams();        // 初始化请求参数
        self::_initAutoload();      // 初始化自动加载
        self::_initDispatch();      // 请求转发
    }

}